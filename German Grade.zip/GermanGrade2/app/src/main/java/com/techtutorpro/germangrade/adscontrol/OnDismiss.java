package com.techtutorpro.germangrade.adscontrol;

public interface OnDismiss {

    void onDismiss();
}
