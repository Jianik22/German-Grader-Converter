package com.techtutorpro.germangrade.adscontrol;

import com.google.android.gms.ads.interstitial.InterstitialAd;

public class Appid {
     public  static InterstitialAd interstitialAd;
    public  static boolean Adtype= true;
    public  static  String BANNER="";
    public  static  String INTERSTITIAL="";
}
